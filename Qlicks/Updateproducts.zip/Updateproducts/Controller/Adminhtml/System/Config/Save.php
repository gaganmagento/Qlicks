<?php

    namespace Qlicks\Updateproducts\Controller\Adminhtml\System\Config;

    use Magento\SalesRule\Model\Rule;
    use Magento\Customer\Model\GroupManagement;
    use Magento\SalesRule\Model\Rule\Condition\Address;
    use Magento\SalesRule\Model\Rule\Condition\Combine;

    class Save extends \Magento\Config\Controller\Adminhtml\System\Config\Save
 {
    protected $request;
    protected $_slicePostFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Config\Model\Config\Structure $configStructure,
        \Magento\Config\Controller\Adminhtml\System\ConfigSectionChecker $sectionChecker,
        \Magento\Config\Model\Config\Factory $configFactory,
        \Magento\Framework\Cache\FrontendInterface $cache,
        \Magento\Framework\Stdlib\StringUtils $string,
        \Modehaus\Spinwheel\Model\SlicepostFactory $slicePostFactory,
        \Magento\SalesRule\Model\RuleFactory $ruleFactory,
        \Magento\SalesRule\Model\RuleRepository $ruleRepository,
        \Magento\Customer\Model\ResourceModel\Group\Collection $customerGroupColl
    ){
        parent::__construct($context, $configStructure, $sectionChecker, $configFactory, $cache, $string);
        $this->_slicePostFactory = $slicePostFactory;
        $this->customerGroupColl = $customerGroupColl;
        $this->ruleFactory = $ruleFactory;
        $this->ruleRepository = $ruleRepository;
    }

     public function execute()
     {

      $data = $this->getRequest()->getParams();
      echo "<pre>";
      print_r($data['slice']);
      die('clone');
    
            $model = $this->_slicePostFactory->create();
            if(isset($data['slice']) && !empty($data['slice'])){
            foreach($data['slice'] as $key=>$value){
                $collection = $model->load($key);
                // echo $collection->getEntityId(); die('test');
                if(!empty($value['slice_label']) && !empty($value['coupon_type'])){
                    if($collection->getEntityId() == $key){
                        // die('colle');
                        $this->updateCartRule($collection->getRuleId(), $value['slice_label'], $value['coupon_type'], $value['gravity']);
                        $postUpdate = $model->load($key);
                        $postUpdate->setSliceLabel($value['slice_label']);
                        $postUpdate->setCouponType($value['coupon_type']);
                        $postUpdate->setCouponValue($value['coupon_value']);
                        $postUpdate->setGravity($value['gravity']);
                        $postUpdate->save();
                    }
                    else{
                        $setData = [
                            'slice_label' => $value['slice_label'],
                            'coupon_type' => $value['coupon_type'],
                            'coupon_value' => $value['coupon_value'],
                            'gravity' => $value['gravity'],
                            'rule_id' => $this->createRules($value['slice_label'], $value['coupon_type'], $value['coupon_value'])
                        ];
                        $model->setData($setData)->save();
                    }
            }
                
            }  
            }
     // die('test');
    $this->messageManager->addSuccess('Message from new admin controller.');
     return parent::execute();
    }
// $ruleName, $discountAmount,

    private function updateCartRule($key, $sliceName, $couponAction, $discountAmount){
        $salesRule = $this->ruleFactory->create();
        $salesRule->load($key);
        $salesRule->setName($sliceName);
        $salesRule->setDescription($sliceName);
        $salesRule->setSimpleAction($couponAction);
        $salesRule->setDiscountAmount($discountAmount);
        $salesRule->save();
    }



    private function createRules($sliceName, $couponAction, $discountAmount)
    {  
        $customerGroups = $this->customerGroupColl->toOptionArray();
        $salesRule = $this->ruleFactory->create();

        $salesRule->setData(
            [
                'name' => $sliceName,
                'description' => $sliceName,
                'is_active' => 1,
                'customer_group_ids' => array_keys($customerGroups), //[0,1,2...]
                'coupon_type' => 1,
                'simple_action' => $couponAction,
                'discount_amount' => $discountAmount,
                'discount_step' => 0,
                'stop_rules_processing' => 0,
                'website_ids' => [1],
                'store_labels' => [
                    0 => 'Label for store with Id=0'
                ]
            ]
        );

        /*including conditions. The required classes for type keys can be found in 
           "conditions_serialized" column*/
        $salesRule->getConditions()->loadArray(
            [
                'type' => Combine::class,
                'attribute' => null,
                'operator' => null,
                'value' => '1',
                'is_value_processed' => null,
                'aggregator' => 'all',
                'conditions' => [
                        [
                            'type' => Address::class,
                            'attribute' => 'base_subtotal_with_discount',
                            'operator' => '>=',
                            'value' => 0,
                            'is_value_processed' => false,
                        ],
                        [
                            'type' => Address::class,
                            'attribute' => 'base_subtotal_with_discount',
                            'operator' => '<=',
                            'value' => 600,
                            'is_value_processed' => false,
                        ]
                ],
            ]
        );

        $salesRule->save();
       return $salesRule->getId();
    }
} 